<?php
  $name = $_POST['name'];
  $password = $_POST['password'];
  $mail = $_POST['mail'];
  $mob_no = $_POST['mob_no'];

  $conn = new mysqli('localhost','root','','test');
 if($conn->connect_error){ 
    die('Connection Failed :' .$conn->connect_error);
  }
  else{
     $stmt = $conn->prepare("insert into registration(name,password,mail,mob_no)
         values(?, ?, ?, ?)");
     $stmt->bind_param("sssi" ,$name, $password, $mail, $mob_no);
     $stmt->execute();
     echo '<script type="text/javascript">'; echo 'alert("Registered Successfully")'; echo '</script>';
     $stmt->close();
     $conn->close();
  }
                                
?>

