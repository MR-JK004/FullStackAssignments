<?php
$host = "localhost";
$username = "root";
$password = "";
$dbname = "test";

$conn = mysqli_connect($host,$username,$password,$dbname);

if(!$conn){
   die("Connection Failed: ".mysqli_connect_errno());
}

session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $mail = $_POST["mail"];
    $password = $_POST["password"];

    $sql = "SELECT * FROM registration WHERE mail = '$mail' AND password = '$password'";
    $result = $conn->query($sql);

    if (isset($_SESSION['mail'])) {
        echo "Welcome, " . $_SESSION['mail'];
        
        header("Location: web.php");
        echo '<script>alert("Login successful!");</script>';
    }else {
        echo "Invalid email or password.";
    }
}

$conn->close();
?>
