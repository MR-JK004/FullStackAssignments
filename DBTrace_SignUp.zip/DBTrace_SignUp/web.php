<?php
require_once('db.php');
$query = "select * from registration";
$res = mysqli_query($conn,$query);
?>
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="style.css">
        <title>index</title>
    </head>

    <body>
    <div style="margin-left: 77%; display:flex;gap:20px;" class="buttons">
        <button style="padding-left:10px;padding-right:10px;"><a style=" text-decoration: none;" href="web.php">Home</a></button>
        <button style="padding-left:10px;padding-right:10px;"><a style=" text-decoration: none;" href="form.html">SignUp</a></button>
        <button style="padding-left:10px;padding-right:10px;"><a style=" text-decoration: none;" href="about.html">About</a></button>
        <button style="padding-left:10px;padding-right:10px;"><a style=" text-decoration: none;" href="contact.html">Contact</a></button>
    </div>
        <div>
            <div>
                <div>
                    <div>
                        <div>
                            <h2 style="text-align:center">Welcome to Quickster Database</h2>
                        </div>
                        <center>
                        <div class="items">
                            <table>
                                <thead class="heading">
                                    <td>ID</td>
                                    <td>Name</td>
                                    <td>Password</td>
                                    <td>Email</td>
                                    <td>Mobile_no</td>
                                </thead>
                                <?php
                                 while($row = mysqli_fetch_assoc($res)){
                                ?>
                                
                                <tr style="text-align: left;">
                                <td><?php echo $row['id']; ?></td>
                                <td><?php echo $row['name']; ?></td>
                                <td><?php echo $row['password']; ?></td>
                                <td><a href="mailto:<?php echo $row['mail'];?>"><?php echo $row['mail'];?></td>
                                <td><?php echo $row['mob_no']; ?></td>
                                </tr>
                                
                                 <?php
                                 }
                                 ?>
                            </table>

                        </div>
                        </center>
                    </div>
                </div>
            </div>
        </div>
        <br><br>
        <div id="reg_box">
        <p style="text-align:center;">If You want to register <button><a style=" text-decoration: none;" href="form.html">Click here</a></button></p>
        </div>
    </body>

    </html>